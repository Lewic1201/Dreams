create
  definer = root@localhost procedure myproc(OUT s int)
BEGIN
  select COUNT(*) into s from users;
END;

