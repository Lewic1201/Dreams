create
  definer = root@localhost procedure myproc2(IN num int)
BEGIN
  SELECT num;
  SET num=num+1;
  SELECT num;
END;

